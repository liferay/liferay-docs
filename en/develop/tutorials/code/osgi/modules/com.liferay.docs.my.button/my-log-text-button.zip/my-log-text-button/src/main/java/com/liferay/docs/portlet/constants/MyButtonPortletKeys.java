package com.liferay.docs.portlet.constants;

/**
 * @author liferay
 */
public class MyButtonPortletKeys {

	public static final String MyButton = "mybutton";

}